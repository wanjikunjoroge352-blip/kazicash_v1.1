# KaziCash — real backend MVP v1.1

This version uses Supabase PostgreSQL for persistent data instead of local `data.json`, so it is suitable for deployment to Vercel.

## Important
- The Supabase **publishable** key is safe for browser/public components when Row Level Security is configured.
- The Supabase **secret** key must stay server-side and must never be placed in the browser or committed to Git.
- Daraja production payments require an eligible Safaricom/M-Pesa business setup and approval. Sandbox testing should happen first.
- Sample jobs are placeholders. They do not generate real money.

## Deployment
Vercel can deploy a ZIP directly through Vercel Drop. After deployment, add the environment variables from `.env.example` in Vercel Project Settings.

## Required backend variables
SUPABASE_URL
SUPABASE_SECRET_KEY
ADMIN_SECRET

Then Daraja variables when ready:
MPESA_ENV
MPESA_CONSUMER_KEY
MPESA_CONSUMER_SECRET
MPESA_SHORTCODE
MPESA_PASSKEY
MPESA_B2C_SHORTCODE
MPESA_INITIATOR_NAME
MPESA_SECURITY_CREDENTIAL
APP_BASE_URL
