# KaziCash v1.1 — deployment checklist

1. Upload this folder/ZIP to Vercel. Vercel supports Express deployment with zero configuration.
2. In Vercel Environment Variables, add the backend variables from `.env.example`.
3. In Supabase SQL Editor, run `supabase_schema.sql`.
4. Start with `MPESA_ENV=sandbox` and Daraja sandbox credentials.
5. Test `/api/health`, worker registration, jobs, submission and withdrawal.
6. Configure Daraja STK and B2C sandbox credentials before payment testing.
7. Only after sandbox testing should production credentials be added.

Never put SUPABASE_SECRET_KEY, ADMIN_SECRET, Daraja consumer secret, initiator credentials, or security credential into browser/public code.
